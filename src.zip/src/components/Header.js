const Header = () => {
    return (
      <header>
        <h1>SpaceVue</h1>
      </header>
    );
  };
  
  export default Header;