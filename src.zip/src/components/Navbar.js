import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      <ul>
      <li>Hello admin</li>
        <li><Link >Home</Link></li>
        <li><Link >About</Link></li>
        <li><Link >Contact</Link></li>
        <li><Link to='/'>Logout</Link></li>
      </ul>
    </nav>
  );
};

export default Navbar;