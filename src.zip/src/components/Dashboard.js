import { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { Doughnut } from 'react-chartjs-2';
import './style.css';
import Header from './Header';
import Navbar from './Navbar';
import Footer from './Footer';
import {Chart, ArcElement} from 'chart.js'
Chart.register(ArcElement);

const Dashboard = () => {
  const [spaceMissionData, setSpaceMissionData] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {

    const fetchData = async () => {
      try {
        const response = await fetch('https://www.ag-grid.com/example-assets/space-mission-data.json');
        const data = await response.json();
        setSpaceMissionData(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false); 
      }
    };

    fetchData();
  }, []);

  // AG-Grid configuration
  const columnDefs = [
    { headerName: 'Mission Name', field: 'mission',pinned: 'left' },
    { headerName: 'Launch Company', field: 'company' },
    { headerName: 'Location', field:'location'},
    { headerName: 'Date', field: 'date' },
    { headerName: 'Time', field: 'time' },
    { headerName: 'Rocket', field:'rocket'},
    { headerName: 'Price', field: 'price' },
    { headerName: 'Successful', field: 'successful' },

  ];
  // Chart data
  const chartData = {
    labels: ['Successful Missions', 'Failed Missions'],
    datasets: [
      {
        data: [
          spaceMissionData.filter((mission) => mission.successful === true).length,
          spaceMissionData.filter((mission) => mission.successful === false).length,
        ],
        backgroundColor: ['#36A2EB', '#FF6384'],
        hoverBackgroundColor: ['#36A2EB', '#FF6384'],
       
      },
    ],
  };

  const chartOptions = {
    tooltips: {
      callbacks: {
        label: function (tooltipItem, data) {
          const label = data.labels[tooltipItem.index] || '';
          const value = data.datasets[0].data[tooltipItem.index];
          return `${label}: ${value}`;
        },
      },
    },
  };

  


return (
  <div>
      <Header />
      <Navbar />
  <div className="dashboard-container">
    <h2>SpaceVue Dashboard</h2>

    <div className="flex-container">
      {/* Chart Container */}
      <div className="chart-container">
        <h3>Mission Outcomes</h3>
        <Doughnut data={chartData} options={chartOptions}  />
      </div>
      {/* AG-Grid Table Container */}
      <div className="ag-theme-alpine" style={{ height: '300px', width: '100%' }}>
        <AgGridReact
          columnDefs={columnDefs}
          rowData={spaceMissionData}
          domLayout='autoHeight'
          pagination={true}
          paginationPageSize={9}
        />
      </div>
      
    </div>
  </div>
  <Footer />
    </div>
);
};



export default Dashboard;
