const Footer = () => {
  return (
    <footer>
      <p>&copy; 2024 SpaceVue. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
